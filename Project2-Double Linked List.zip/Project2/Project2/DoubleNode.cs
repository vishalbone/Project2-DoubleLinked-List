﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    class DoubleNode
    {
        public int data;
        public DoubleNode prevadd;
        public DoubleNode nextadd;
    }
    class nodelist
    {
        public DoubleNode head;
        public int count;
        public nodelist()
        {
            head = null;
            count = 0;
        }

        public DoubleNode createnode(int ele)
        {
            DoubleNode temp = new DoubleNode();
            temp.data = ele;
            temp.nextadd = null;
            temp.prevadd = null;
            count++;
            return temp;
        }
        public void insertbegin(int ele)
        {
            DoubleNode newnode = createnode(ele);
            if (head == null)
            {
                head = newnode;
            }
            else
            {
                newnode.nextadd = head;
                head.prevadd = newnode;
                head = newnode;
            }

        }
        public void insertend(int ele)
        {
            DoubleNode newnode = createnode(ele);
            if (head == null)
                head = newnode;
            else
            {
                DoubleNode temp = head;
                while (temp.nextadd != null)
                {
                    temp = temp.nextadd;
                }
                temp.nextadd = newnode;
                newnode.prevadd = temp;
            }
        }
        public void insertpos(int ele, int pos)
        {
            if (pos == 1)
                insertbegin(ele);
            else if (pos == count + 1)
                insertend(ele);
            else
            {
                DoubleNode newnode = createnode(ele);
                DoubleNode pn, cn;
                pn = cn = head;
                for (int i = 1; i < pos; i++)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                pn.nextadd = newnode;
                newnode.prevadd = pn;
                newnode.nextadd = cn;
                cn.prevadd = newnode;
            }
        }
        public int findele(int ele)
        {

            int flag = -1;
            int i = 0;
            DoubleNode temp = head;
            while (temp != null)
            {
                i++;
                if (temp.data == ele)
                    return i;
                temp = temp.nextadd;
            }
            return flag;

        }
        public int findoccurence(int ele, int occur)
        {
            int flag = -1;
            int pos = 0;
            int count = 0;
            DoubleNode temp = head;
            while (temp.nextadd != null)
            {
                pos++;
                if (temp.data == ele)
                    count++;
                if (count == occur)
                {
                    return pos;
                }
                temp = temp.nextadd;
            }
            if (count == 0)
                return flag;
            else
                return -2;
        }
        public void Deletebegin()
        {
            Console.WriteLine("_____________________________");
            if (head == null)
                Console.WriteLine("No element in the list------Delete is not possible");
            else
            {
                DoubleNode temp = head;
                head = head.nextadd;
                if (head != null)
                {
                    head.prevadd = null;
                }
                Console.WriteLine("Deleting the element = " + temp.data);
                temp = null;
                count--;
            }
            Console.WriteLine("_____________________________");
        }
        public void DeleteEnd()
        {
            Console.WriteLine("_____________________________");
            if (head == null)
                Console.WriteLine("No element in the list------Delete is not possible");
            else
            {
                DoubleNode pn, cn;
                cn = pn = head;
                while (cn.nextadd != null)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                if (pn == cn)
                {
                    head = null;
                }
                pn.nextadd = null;
                Console.WriteLine("Deleting the element = " + cn.data);
                cn = null;
                count--;
            }
            Console.WriteLine("_____________________________");
        }
        public void deletepos(int pos)
        {
            if (pos == 1)
                Deletebegin();
            else if (pos == count)
                DeleteEnd();
            else
            {
                DoubleNode cn, pn;
                cn = pn = head;
                for (int i = 1; i < pos; i++)
                {
                    pn = cn;
                    cn = cn.nextadd;
                }
                pn.nextadd = cn.nextadd;
                cn.nextadd.prevadd = pn;
                Console.WriteLine("Deleting the element = " + cn.data);
                cn = null;
                count--;
            }
        }
        public void displayfarward()
        {
            Console.WriteLine("_____________________________");
            if (head == null)
            {
                Console.WriteLine("No elements in the list");
            }
            else
            {
                DoubleNode temp = head;
                while (temp != null)
                {
                    Console.Write(temp.data + "--->");
                    temp = temp.nextadd;
                }
                Console.WriteLine("null");
            }
            Console.WriteLine("_____________________________");
        }
        public DoubleNode lastnode()
        {
            DoubleNode ln = head;
            while (ln.nextadd != null)
            {
                ln = ln.nextadd;
            }
            return ln;
        }
        public void displaybackward()
        {
            Console.WriteLine("_____________________________");
            if (head == null)
            {
                Console.WriteLine("No elements in the list");
            }
            else
            {
                DoubleNode ln = lastnode();
                while (ln != null)
                {
                    Console.Write(ln.data + "--->");
                    ln = ln.prevadd;
                }
                Console.WriteLine("null");
            }
            Console.WriteLine("_____________________________");
        }
    }
}
