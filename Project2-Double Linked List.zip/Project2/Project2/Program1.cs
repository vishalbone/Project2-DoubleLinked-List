﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    class Program1
    {
        static void Main(string[] args)
        {
            nodelist ob = new nodelist();
            int ch, ele, pos, key, occur;
            do
            {
                Console.WriteLine("1 Insert in the begining");
                Console.WriteLine("2 Insert in the End");
                Console.WriteLine("3 Insert at given position");
                Console.WriteLine("4 Enter the search key ");
                Console.WriteLine("5 Enter the search key and its occurence");
                Console.WriteLine("6 Delete from start");
                Console.WriteLine("7 Delete from End");
                Console.WriteLine("8 Delete At given position");
                Console.WriteLine("9 displayfarward");
                Console.WriteLine("10 displaybackward");
                Console.WriteLine("11 Exit");
                Console.WriteLine("Enter the choice");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter the element");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertbegin(ele);
                        break;
                    case 2:
                        Console.WriteLine("Enter the element");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertend(ele);
                        break;
                    case 3:
                        do
                        {
                            Console.WriteLine("Enter the element");
                            ele = int.Parse(Console.ReadLine());
                            Console.WriteLine("Enter the position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ob.count + 1);
                        ob.insertpos(ele, pos);
                        break;
                    case 4:
                        Console.WriteLine("Enter the search key");
                        key = int.Parse(Console.ReadLine());
                        pos = ob.findele(key);
                        Console.WriteLine("_____________________________");
                        if (pos == -1)
                            Console.WriteLine("Search key is not found");
                        else
                            Console.WriteLine("Search key is found at position = " + pos);
                        Console.WriteLine("_____________________________");
                        break;
                    case 5:
                        Console.WriteLine("Enter the search key");
                        key = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter the occurence");
                        occur = int.Parse(Console.ReadLine());
                        pos = ob.findoccurence(key, occur);
                        Console.WriteLine("_____________________________");
                        if (pos == -1)
                            Console.WriteLine("Key not found");
                        else if (pos == -2)
                            Console.WriteLine("key found but not occurance");
                        else
                            Console.WriteLine("key {0} for {1} occurance is found at {2} position", key, occur, pos);
                        Console.WriteLine("_____________________________");
                        break;
                    case 6: ob.Deletebegin(); break;
                    case 7: ob.DeleteEnd(); break;
                    case 9: ob.displayfarward(); break;
                    case 10: ob.displaybackward(); break;
                    case 11: Console.WriteLine("You successfully log out from program"); break;
                    default: Console.WriteLine("Invallid choice-----Enter the correct choice"); break;

                }
            } while (ch != 11);
        }
    }
}
